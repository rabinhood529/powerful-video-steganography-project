# Enhanced Video Steganography Features Guide

## Overview
This document describes the enhanced features added to the Video Steganography Tool. The application now includes advanced quality analysis, histogram visualization, and improved GUI organization.

## New Features

### 1. GUI Improvements

#### Tab Organization
- **Encode Tab**: Renamed from "Hide Data" - contains all encoding functionality with quality analysis
- **Decode Tab**: Renamed from "Extract Data" - contains all decoding functionality
- **Settings Tab**: Configuration options (unchanged)
- **Capacity Analysis Tab**: Video capacity analysis (unchanged)

#### Quality Analysis Section (Encode Tab)
The Quality Analysis section appears after successful encoding and includes:
- **Metrics Display**: Shows MSE, PSNR, histogram correlation, and payload capacity
- **Histogram Controls**: Buttons to visualize different histogram comparisons
- **Interactive Plots**: Matplotlib-based histogram visualizations

### 2. Histogram Visualization Features

#### Available Histogram Views
1. **Cover Video Histogram**: Shows the original video's pixel intensity distribution
2. **Stego Video Histogram**: Shows the steganographic video's pixel intensity distribution
3. **Histogram Difference**: Shows the absolute difference between cover and stego histograms
4. **Overlay Comparison**: Overlays both histograms for direct comparison (Cover in red, Stego in blue)

#### Histogram Controls
- **Show Cover Histogram**: Displays original video histogram
- **Show Stego Histogram**: Displays steganographic video histogram
- **Show Histogram Difference**: Shows differences between histograms
- **Show Overlay Comparison**: Overlays both histograms for comparison

### 3. Quality Metrics

#### Automatic Calculation
After successful encoding, the following metrics are automatically calculated:

1. **MSE (Mean Square Error)**
   - Measures the average squared difference between cover and stego frames
   - Lower values indicate better quality preservation
   - Range: 0 to infinity (lower is better)

2. **PSNR (Peak Signal-to-Noise Ratio)**
   - Measures the ratio between maximum possible signal power and noise power
   - Higher values indicate better quality preservation
   - Range: 0 to infinity dB (higher is better)
   - Values > 30 dB are generally considered good quality

3. **Histogram Correlation**
   - Measures how similar the cover and stego histograms are
   - Range: -1 to 1 (closer to 1 is better)
   - Values close to 1 indicate minimal histogram changes

4. **Payload Capacity**
   - Shows the percentage of maximum capacity used
   - Range: 0 to 100%
   - Helps understand how much of the available space was utilized

#### Quality Assessment Guidelines
- **MSE**: Lower values = Better quality
- **PSNR**: Higher values = Better quality (>30 dB is good)
- **Correlation**: Higher values = More similar histograms
- **Payload Capacity**: Shows space utilization efficiency

### 4. Technical Implementation

#### New Methods Added
- `calculate_histogram()`: Calculates pixel intensity histograms from video frames
- `calculate_mse()`: Computes Mean Square Error between video frames
- `calculate_psnr()`: Computes Peak Signal-to-Noise Ratio from MSE
- `calculate_histogram_correlation()`: Calculates correlation between histograms
- `calculate_payload_capacity()`: Computes payload capacity percentage
- `analyze_quality_metrics()`: Orchestrates quality analysis process
- `display_quality_metrics()`: Updates GUI with metric results
- `show_cover_histogram()`: Displays cover video histogram
- `show_stego_histogram()`: Displays stego video histogram
- `show_histogram_difference()`: Shows histogram differences
- `show_histogram_overlay()`: Shows overlaid histograms

#### Enhanced Video Processor
- Added `load_video_frames()` method to load video frames for analysis
- Supports loading a specified number of frames for performance optimization

#### Dependencies
- **scipy**: For statistical correlation calculations
- **math**: For logarithmic calculations in PSNR
- **matplotlib**: For histogram visualization
- **numpy**: For numerical operations
- **OpenCV**: For video frame processing

### 5. Usage Workflow

#### Encoding with Quality Analysis
1. Select cover video in the Encode tab
2. Select secret file to hide
3. Configure encryption (optional)
4. Set output path
5. Click "Encode Data in Video"
6. After successful encoding:
   - Quality Analysis section appears
   - Metrics are automatically calculated and displayed
   - Histogram controls become available
   - Click histogram buttons to view different visualizations

#### Decoding
1. Switch to Decode tab
2. Select steganographic video
3. Configure decryption (if used during encoding)
4. Set output directory
5. Click "Decode Hidden Data"

### 6. Performance Considerations

#### Optimization Features
- **Limited Frame Analysis**: Only analyzes first 10 frames by default for performance
- **Efficient Histogram Calculation**: Uses numpy operations for speed
- **Lazy Loading**: Quality analysis only runs after successful encoding
- **Memory Management**: Frames are processed in batches to manage memory usage

#### Recommended Settings
- For large videos: Consider reducing the number of frames analyzed
- For detailed analysis: Use AVI format for best quality preservation
- For quick testing: Use smaller video files for faster processing

### 7. File Format Support

#### Supported Secret Files
- **Text**: .txt
- **Documents**: .doc, .docx
- **Images**: .jpg, .jpeg, .png, .bmp, .gif
- **Videos**: .mp4, .avi, .mov, .mkv
- **Audio**: .mp3, .wav, .flac

#### Recommended Video Formats
- **Cover Videos**: .mp4, .avi, .mov, .mkv
- **Output Format**: .avi (recommended for best steganography quality)

### 8. Troubleshooting

#### Common Issues
1. **Quality Analysis Not Appearing**: Ensure encoding was successful
2. **Histogram Display Issues**: Check that matplotlib is properly installed
3. **Memory Issues**: Reduce the number of frames analyzed for large videos
4. **Slow Performance**: Use smaller videos or reduce analysis frame count

#### Error Messages
- "No cover histogram data available": Quality analysis not yet performed
- "Cannot load frames for quality analysis": Video file access issues
- "Error in quality analysis": General analysis error, check logs

### 9. Future Enhancements

#### Potential Improvements
- Configurable frame analysis count
- Export quality metrics to file
- Advanced statistical analysis
- Real-time quality monitoring during encoding
- Custom histogram bin configurations

## Conclusion

The enhanced Video Steganography Tool now provides comprehensive quality analysis capabilities, making it easier to assess the impact of steganographic operations on video quality. The new histogram visualization features provide valuable insights into how data hiding affects pixel distributions, while the quality metrics offer quantitative measures of quality preservation.

All existing functionality has been preserved, ensuring backward compatibility while adding powerful new analysis capabilities.
