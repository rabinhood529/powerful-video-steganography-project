"""
Video Steganography Application - Complete Fixed Version
Main module containing the Tkinter GUI and application logic

Requirements:
- OpenCV (cv2): pip install opencv-python
- NumPy: pip install numpy
- Pillow: pip install Pillow
- python-docx: pip install python-docx
- cryptography: pip install cryptography
- matplotlib: pip install matplotlib
- scipy: pip install scipy

Author: AI Assistant
Compatible with: Windows 10, VS Code, Python 3.7+
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog, scrolledtext
import cv2
import numpy as np
import os
import threading
import time
from datetime import datetime
from pathlib import Path
import hashlib
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import base64
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib
matplotlib.use('TkAgg')
from scipy import stats
import math

# Import steganography modules
from video_processor import VideoProcessor
from file_handler import FileHandler
from steganography_engine import SteganographyEngine


class HomeWindow:
    """Home window with Encode and Decode buttons"""
    
    def __init__(self, root):
        self.root = root
        self.root.title("Video Steganography App")
        self.root.geometry("600x500")
        self.root.resizable(True, True)
        
        self.center_window()
        self.setup_gui()
    
    def center_window(self):
        """Center the window on screen"""
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')
    
    def setup_gui(self):
        """Setup the home GUI"""
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True)
        main_frame.grid_rowconfigure(0, weight=1)
        main_frame.grid_columnconfigure(0, weight=1)
        
        container = ttk.Frame(main_frame)
        container.grid(row=0, column=0, sticky="nsew", padx=20, pady=20)
        
        welcome_label = ttk.Label(container, text="Video Steganography App", 
                                 font=("Arial", 24, "bold"))
        welcome_label.pack(pady=(0, 20))
        
        subtitle_label = ttk.Label(container, 
                                  text="Hide and extract secret data in video files",
                                  font=("Arial", 12))
        subtitle_label.pack(pady=(0, 30))
        
        desc_label = ttk.Label(container, 
                              text="Choose an operation to get started:",
                              font=("Arial", 14))
        desc_label.pack(pady=(0, 30))
        
        button_frame = ttk.Frame(container)
        button_frame.pack(expand=True)
        
        encode_btn = ttk.Button(button_frame, text="Encode Data in Video", 
                               command=self.open_encode_window, 
                               style="Accent.TButton")
        encode_btn.pack(pady=15, ipadx=30, ipady=12)
        
        decode_btn = ttk.Button(button_frame, text="Decode Hidden Data", 
                               command=self.open_decode_window, 
                               style="Accent.TButton")
        decode_btn.pack(pady=15, ipadx=30, ipady=12)
        
        info_frame = ttk.LabelFrame(container, text="About", padding=15)
        info_frame.pack(fill=tk.X, pady=(30, 0))
        
        info_text = """This tool allows you to:
• Hide secret files (text, images, videos, audio, documents) inside video files
• Extract hidden data from steganographic videos
• Analyze video quality and steganographic impact
• Use LSB or DCT algorithms for data hiding
• Secure your data with optional password encryption"""
        
        info_label = ttk.Label(info_frame, text=info_text, justify=tk.LEFT)
        info_label.pack()
    
    def open_encode_window(self):
        """Open the encode window"""
        encode_window = EncodeWindow(self.root)
    
    def open_decode_window(self):
        """Open the decode window"""
        decode_window = DecodeWindow(self.root)


class EncodeWindow:
    """Encode window with all encoding functionality and quality analysis"""
    
    def __init__(self, parent=None):
        self.parent = parent
        self.window = tk.Toplevel(parent) if parent else tk.Tk()
        self.window.title("Encode Data in Video")
        self.window.geometry("900x750")
        self.window.resizable(True, True)
        self.window.minsize(700, 600)
        
        self.center_window()
        
        self.video_processor = VideoProcessor()
        self.file_handler = FileHandler()
        self.stego_engine = SteganographyEngine()
        
        self.cover_video_path = tk.StringVar()
        self.secret_file_path = tk.StringVar()
        self.output_path = tk.StringVar()
        self.password = tk.StringVar()
        self.use_password = tk.BooleanVar()
        self.algorithm = tk.StringVar(value="LSB")
        
        self.progress_var = tk.DoubleVar()
        self.status_var = tk.StringVar(value="Ready")
        
        self.video_info = {}
        self.max_secret_size = 0
        
        self.quality_metrics = {}
        self.cover_histogram = None
        self.stego_histogram = None
        self.cover_frames = None
        self.stego_frames = None
        
        self.histogram_window = None
        
        self.setup_gui()
        self.log_message("Encode window initialized")
    
    def center_window(self):
        """Center the window on screen"""
        self.window.update_idletasks()
        width = self.window.winfo_width()
        height = self.window.winfo_height()
        x = (self.window.winfo_screenwidth() // 2) - (width // 2)
        y = (self.window.winfo_screenheight() // 2) - (height // 2)
        self.window.geometry(f'{width}x{height}+{x}+{y}')
    
    def setup_gui(self):
        """Setup the encode GUI with improved layout"""
        main_frame = ttk.Frame(self.window)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=0, pady=0)
        
        canvas = tk.Canvas(main_frame)
        scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        # Create window with proper width binding
        canvas_window = canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Bind canvas width to scrollable_frame width
        def configure_scroll_width(event):
            canvas.itemconfig(canvas_window, width=event.width)
        canvas.bind("<Configure>", configure_scroll_width)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        title_label = ttk.Label(scrollable_frame, text="Encode Data in Video", 
                               font=("Arial", 16, "bold"))
        title_label.pack(pady=10, padx=20)
        
        # Cover video section
        cover_frame = ttk.LabelFrame(scrollable_frame, text="Cover Video", padding=10)
        cover_frame.pack(fill=tk.X, padx=20, pady=5)
        
        cover_entry_frame = ttk.Frame(cover_frame)
        cover_entry_frame.pack(fill=tk.X)
        ttk.Entry(cover_entry_frame, textvariable=self.cover_video_path).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        ttk.Button(cover_entry_frame, text="Browse", command=self.select_cover_video).pack(side=tk.RIGHT)
        
        # Video info
        self.video_info_frame = ttk.LabelFrame(scrollable_frame, text="Video Information", padding=10)
        self.video_info_frame.pack(fill=tk.X, padx=10, pady=5)
        
        self.video_info_text = scrolledtext.ScrolledText(self.video_info_frame, height=4, wrap=tk.WORD)
        self.video_info_text.pack(fill=tk.X)
        
        # Secret file section
        secret_frame = ttk.LabelFrame(scrollable_frame, text="Secret File", padding=10)
        secret_frame.pack(fill=tk.X, padx=10, pady=5)
        
        secret_entry_frame = ttk.Frame(secret_frame)
        secret_entry_frame.pack(fill=tk.X)
        ttk.Entry(secret_entry_frame, textvariable=self.secret_file_path).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        ttk.Button(secret_entry_frame, text="Browse", command=self.select_secret_file).pack(side=tk.RIGHT)
        
        self.size_warning_label = ttk.Label(secret_frame, text="", foreground="red")
        self.size_warning_label.pack(pady=(5, 0))
        
        # Algorithm section
        algo_frame = ttk.LabelFrame(scrollable_frame, text="Steganography Algorithm", padding=10)
        algo_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Radiobutton(algo_frame, text="LSB (Least Significant Bit)", 
                       variable=self.algorithm, value="LSB").pack(anchor=tk.W)
        ttk.Radiobutton(algo_frame, text="DCT (Discrete Cosine Transform)", 
                       variable=self.algorithm, value="DCT").pack(anchor=tk.W)
        
        # Password section
        password_frame = ttk.LabelFrame(scrollable_frame, text="Encryption (Optional)", padding=10)
        password_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Checkbutton(password_frame, text="Use password encryption", 
                       variable=self.use_password).pack(anchor=tk.W)
        
        pwd_entry_frame = ttk.Frame(password_frame)
        pwd_entry_frame.pack(fill=tk.X, pady=(5, 0))
        ttk.Label(pwd_entry_frame, text="Password:").pack(side=tk.LEFT)
        ttk.Entry(pwd_entry_frame, textvariable=self.password, show="*").pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5, 0))
        
        # Output section
        output_frame = ttk.LabelFrame(scrollable_frame, text="Output Video", padding=10)
        output_frame.pack(fill=tk.X, padx=10, pady=5)
        
        output_entry_frame = ttk.Frame(output_frame)
        output_entry_frame.pack(fill=tk.X)
        ttk.Entry(output_entry_frame, textvariable=self.output_path).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        ttk.Button(output_entry_frame, text="Browse", command=self.select_output_path).pack(side=tk.RIGHT)
        
        # Encode button
        ttk.Button(scrollable_frame, text="Encode Data in Video", 
                  command=self.encode_data_thread, style="Accent.TButton").pack(pady=15)
        
        # Quality Analysis section - IMPROVED
        self.quality_frame = ttk.LabelFrame(scrollable_frame, text="Quality Analysis Results", padding=10)
        self.quality_frame.pack(fill=tk.X, padx=10, pady=5)
        self.quality_frame.pack_forget()
        
        # Metrics display
        self.metrics_text = tk.Text(self.quality_frame, height=12, wrap=tk.WORD, font=("Courier", 9))
        self.metrics_text.pack(fill=tk.X, pady=(0, 10))
        
        # IMPROVED Histogram buttons
        histogram_label = ttk.Label(self.quality_frame, text="Histogram Analysis Tools:", font=("Arial", 10, "bold"))
        histogram_label.pack(anchor=tk.W, pady=(5, 5))
        
        button_frame1 = ttk.Frame(self.quality_frame)
        button_frame1.pack(fill=tk.X, pady=2)
        
        ttk.Button(button_frame1, text="📊 Grayscale Histogram", 
                  command=self.show_grayscale_histogram, width=28).pack(side=tk.LEFT, padx=2)
        ttk.Button(button_frame1, text="🎨 RGB Channel Histograms", 
                  command=self.show_rgb_histograms, width=28).pack(side=tk.LEFT, padx=2)
        
        button_frame2 = ttk.Frame(self.quality_frame)
        button_frame2.pack(fill=tk.X, pady=2)
        
        ttk.Button(button_frame2, text="📉 Difference Histogram", 
                  command=self.show_difference_histogram, width=28).pack(side=tk.LEFT, padx=2)
        ttk.Button(button_frame2, text="🔬 Bit-Plane Analysis", 
                  command=self.show_bitplane_analysis, width=28).pack(side=tk.LEFT, padx=2)
        
        button_frame3 = ttk.Frame(self.quality_frame)
        button_frame3.pack(fill=tk.X, pady=2)
        
        ttk.Button(button_frame3, text="📈 Statistical Detection", 
                  command=self.show_statistical_detection, width=28).pack(side=tk.LEFT, padx=2)
        
        # Progress section
        progress_frame = ttk.LabelFrame(scrollable_frame, text="Progress", padding=10)
        progress_frame.pack(fill=tk.X, padx=10, pady=5)
        
        self.progress_bar = ttk.Progressbar(progress_frame, variable=self.progress_var, 
                                          maximum=100, mode='determinate')
        self.progress_bar.pack(fill=tk.X, pady=(0, 5))
        
        self.status_label = ttk.Label(progress_frame, textvariable=self.status_var)
        self.status_label.pack()
        
        # Log section
        log_frame = ttk.LabelFrame(scrollable_frame, text="Log", padding=10)
        log_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        self.log_text = scrolledtext.ScrolledText(log_frame, height=6)
        self.log_text.pack(fill=tk.BOTH, expand=True)
        
        ttk.Button(log_frame, text="Clear Log", command=self.clear_log).pack(pady=(5, 0))
    
    def log_message(self, message):
        """Add message to log with timestamp"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        log_entry = f"[{timestamp}] {message}\n"
        self.log_text.insert(tk.END, log_entry)
        self.log_text.see(tk.END)
        self.window.update_idletasks()
    
    def clear_log(self):
        """Clear the log window"""
        self.log_text.delete(1.0, tk.END)
    
    def select_cover_video(self):
        """Select cover video file"""
        filetypes = [
            ("Video files", "*.mp4 *.avi *.mov *.mkv"),
            ("All files", "*.*")
        ]
        
        filename = filedialog.askopenfilename(
            title="Select Cover Video",
            filetypes=filetypes
        )
        
        if filename:
            self.cover_video_path.set(filename)
            self.analyze_video(filename)
    
    def select_secret_file(self):
        """Select secret file to hide"""
        filetypes = [
            ("All supported files", "*.txt *.doc *.docx *.jpg *.jpeg *.png *.bmp *.gif *.mp4 *.avi *.mov *.mkv *.mp3 *.wav *.flac"),
            ("Text files", "*.txt"),
            ("Document files", "*.doc *.docx"),
            ("Image files", "*.jpg *.jpeg *.png *.bmp *.gif"),
            ("Video files", "*.mp4 *.avi *.mov *.mkv"),
            ("Audio files", "*.mp3 *.wav *.flac"),
            ("All files", "*.*")
        ]
        
        filename = filedialog.askopenfilename(
            title="Select Secret File",
            filetypes=filetypes
        )
        
        if filename:
            self.secret_file_path.set(filename)
            self.check_file_size_compatibility()
    
    def select_output_path(self):
        """Select output path for steganographic video"""
        filename = filedialog.asksaveasfilename(
            title="Save Steganographic Video As",
            defaultextension=".avi",
            filetypes=[("AVI files", "*.avi"), ("MP4 files", "*.mp4")]
        )
        
        if filename:
            self.output_path.set(filename)
    
    def analyze_video(self, video_path):
        """Analyze video and display information"""
        try:
            self.log_message(f"Analyzing video: {os.path.basename(video_path)}")
            
            info = self.video_processor.get_video_info(video_path)
            self.video_info = info
            
            file_size_mb = info['file_size'] / (1024 * 1024)
            if file_size_mb > 50:
                messagebox.showwarning("File Size Warning", 
                                     f"Video file is {file_size_mb:.1f} MB. "
                                     "Files larger than 50 MB may take longer to process.")
            
            self.max_secret_size = self.stego_engine.calculate_max_payload_size(
                info['width'], info['height'], info['frame_count'], self.algorithm.get()
            )
            
            info_text = f"""File: {os.path.basename(video_path)}
Size: {file_size_mb:.2f} MB
Resolution: {info['width']}x{info['height']} ({self.get_resolution_name(info['width'], info['height'])})
Duration: {info['duration']:.2f} seconds
Frame Rate: {info['fps']:.2f} fps
Frame Count: {info['frame_count']}
Codec: {info['codec']}
Maximum Secret File Size: {self.max_secret_size / 1024:.2f} KB"""
            
            self.video_info_text.delete(1.0, tk.END)
            self.video_info_text.insert(1.0, info_text)
            
            self.log_message(f"Video analysis complete. Max payload: {self.max_secret_size / 1024:.2f} KB")
            
        except Exception as e:
            self.log_message(f"Error analyzing video: {str(e)}")
            messagebox.showerror("Error", f"Failed to analyze video:\n{str(e)}")
    
    def get_resolution_name(self, width, height):
        """Get resolution name"""
        if height <= 480:
            return "480p"
        elif height <= 720:
            return "720p"
        elif height <= 1080:
            return "1080p"
        else:
            return f"{height}p"
    
    def check_file_size_compatibility(self):
        """Check if secret file can fit in cover video"""
        if not self.secret_file_path.get() or self.max_secret_size == 0:
            return
        
        try:
            secret_size = os.path.getsize(self.secret_file_path.get())
            
            if secret_size > self.max_secret_size:
                warning_text = f"⚠️ Secret file ({secret_size / 1024:.2f} KB) is too large!\nMaximum size: {self.max_secret_size / 1024:.2f} KB"
                self.size_warning_label.config(text=warning_text, foreground="red")
                self.log_message(f"Warning: Secret file too large")
            else:
                self.size_warning_label.config(text=f"✓ File size OK ({secret_size / 1024:.2f} KB)", foreground="green")
                self.log_message(f"Secret file size OK: {secret_size / 1024:.2f} KB")
                
        except Exception as e:
            self.log_message(f"Error checking file size: {str(e)}")
    
    def encode_data_thread(self):
        """Start encode in thread"""
        thread = threading.Thread(target=self.encode_data)
        thread.daemon = True
        thread.start()
    
    def encode_data(self):
        """Encode data in video"""
        try:
            if not self.cover_video_path.get():
                messagebox.showerror("Error", "Please select a cover video")
                return
            
            if not self.secret_file_path.get():
                messagebox.showerror("Error", "Please select a secret file")
                return
            
            if not self.output_path.get():
                messagebox.showerror("Error", "Please specify output path")
                return
            
            if not self.output_path.get().lower().endswith('.avi'):
                result = messagebox.askyesno("Format Warning", 
                    "You're not using AVI format. Video compression may corrupt hidden data.\n\n"
                    "Do you want to continue anyway?")
                if not result:
                    return
            
            self.status_var.set("Hiding data...")
            self.progress_var.set(10)
            self.log_message("Starting data hiding process...")
            
            secret_data = self.file_handler.read_file(self.secret_file_path.get())
            if secret_data is None:
                messagebox.showerror("Error", "Failed to read secret file")
                return
            
            filename = os.path.basename(self.secret_file_path.get())
            extension = os.path.splitext(filename)[1]
            
            metadata = {
                'filename': filename,
                'extension': extension,
                'size': len(secret_data),
                'encrypted': self.use_password.get() and bool(self.password.get())
            }
            
            if self.use_password.get() and self.password.get():
                self.log_message("Encrypting data...")
                try:
                    secret_data = self.encrypt_data(secret_data, self.password.get())
                    self.log_message("Data encrypted successfully")
                except Exception as e:
                    self.log_message(f"Encryption failed: {str(e)}")
                    messagebox.showerror("Error", f"Encryption failed: {str(e)}")
                    return
            
            self.progress_var.set(30)
            
            success = self.stego_engine.hide_data_with_backup(
                self.cover_video_path.get(),
                self.output_path.get(),
                secret_data,
                metadata,
                self.algorithm.get(),
                self.update_progress
            )
            
            if success:
                self.progress_var.set(100)
                self.status_var.set("Data encoded successfully!")
                self.log_message(f"Success! Steganographic video saved to: {self.output_path.get()}")
                
                self.analyze_quality_metrics(
                    self.cover_video_path.get(),
                    self.output_path.get(),
                    len(secret_data)
                )
                
                messagebox.showinfo("Success", 
                    f"Data encoded successfully in video!\n"
                    f"Saved to: {self.output_path.get()}\n\n"
                    f"Quality analysis has been performed.")
            else:
                self.log_message("Failed to encode data")
                messagebox.showerror("Error", "Failed to encode data in video")
                self.status_var.set("Error occurred")
            
        except Exception as e:
            self.log_message(f"Error: {str(e)}")
            messagebox.showerror("Error", f"Failed to hide data:\n{str(e)}")
            self.status_var.set("Error occurred")
    
    def update_progress(self, percentage):
        """Update progress bar"""
        self.progress_var.set(percentage)
        self.window.update_idletasks()
    
    def encrypt_data(self, data, password):
        """Encrypt data using password"""
        password_bytes = password.encode()
        salt = os.urandom(16)
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        key = base64.urlsafe_b64encode(kdf.derive(password_bytes))
        fernet = Fernet(key)
        encrypted_data = fernet.encrypt(data)
        return salt + encrypted_data

    def calculate_histogram(self, frames):
        """Calculate histogram from frames"""
        if frames is None or len(frames) == 0:
            return None
        
        hist_data = []
        for frame in frames:
            gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            hist_data.extend(gray_frame.flatten())
        
        return np.array(hist_data)

    def calculate_mse(self, cover_frames, stego_frames):
        """Calculate MSE"""
        if cover_frames is None or stego_frames is None:
            return 0
        
        min_frames = min(len(cover_frames), len(stego_frames))
        cover_frames = cover_frames[:min_frames]
        stego_frames = stego_frames[:min_frames]
        
        mse_total = 0
        for cover_frame, stego_frame in zip(cover_frames, stego_frames):
            cover_gray = cv2.cvtColor(cover_frame, cv2.COLOR_BGR2GRAY)
            stego_gray = cv2.cvtColor(stego_frame, cv2.COLOR_BGR2GRAY)
            mse_frame = np.mean((cover_gray.astype(np.float32) - stego_gray.astype(np.float32)) ** 2)
            mse_total += mse_frame
        
        return mse_total / min_frames if min_frames > 0 else 0

    def calculate_psnr(self, mse):
        """Calculate PSNR"""
        if mse == 0:
            return float('inf')
        return 20 * math.log10(255.0 / math.sqrt(mse))

    def calculate_ssim(self, cover_frames, stego_frames):
        """Calculate SSIM"""
        if cover_frames is None or stego_frames is None:
            return 0.0
        
        min_frames = min(len(cover_frames), len(stego_frames))
        cover_frames = cover_frames[:min_frames]
        stego_frames = stego_frames[:min_frames]

        L = 255.0
        k1, k2 = 0.01, 0.03
        c1 = (k1 * L) ** 2
        c2 = (k2 * L) ** 2

        ssim_values = []
        for cover_frame, stego_frame in zip(cover_frames, stego_frames):
            x = cv2.cvtColor(cover_frame, cv2.COLOR_BGR2GRAY).astype(np.float32)
            y = cv2.cvtColor(stego_frame, cv2.COLOR_BGR2GRAY).astype(np.float32)

            mu_x, mu_y = np.mean(x), np.mean(y)
            sigma_x2, sigma_y2 = np.var(x), np.var(y)
            sigma_xy = np.mean((x - mu_x) * (y - mu_y))

            numerator = (2 * mu_x * mu_y + c1) * (2 * sigma_xy + c2)
            denominator = (mu_x ** 2 + mu_y ** 2 + c1) * (sigma_x2 + sigma_y2 + c2)
            ssim = 1.0 if denominator == 0 else numerator / denominator
            ssim_values.append(float(np.clip(ssim, -1.0, 1.0)))

        return float(np.mean(ssim_values)) if ssim_values else 0.0

    def calculate_histogram_correlation(self, cover_hist, stego_hist):
        """Calculate histogram correlation"""
        if cover_hist is None or stego_hist is None:
            return 0
        
        min_len = min(len(cover_hist), len(stego_hist))
        correlation, _ = stats.pearsonr(cover_hist[:min_len], stego_hist[:min_len])
        return correlation if not np.isnan(correlation) else 0

    def calculate_payload_capacity(self, secret_data_size, max_capacity):
        """Calculate payload capacity percentage"""
        if max_capacity == 0:
            return 0
        return (secret_data_size / max_capacity) * 100
    
    def chi_square_test(self, cover_frames, stego_frames):
        """Perform chi-square test for LSB steganalysis"""
        if cover_frames is None or stego_frames is None:
            return 0, 1.0
        
        try:
            # Sample frames for chi-square test
            min_frames = min(len(cover_frames), len(stego_frames), 5)
            
            chi_square_values = []
            p_values = []
            
            for i in range(min_frames):
                cover_gray = cv2.cvtColor(cover_frames[i], cv2.COLOR_BGR2GRAY).flatten()
                stego_gray = cv2.cvtColor(stego_frames[i], cv2.COLOR_BGR2GRAY).flatten()
                
                # Create histograms
                cover_hist, _ = np.histogram(cover_gray, bins=256, range=(0, 256))
                stego_hist, _ = np.histogram(stego_gray, bins=256, range=(0, 256))
                
                # Avoid division by zero
                cover_hist = cover_hist + 1
                stego_hist = stego_hist + 1
                
                # Chi-square statistic
                chi_square = np.sum((cover_hist - stego_hist) ** 2 / cover_hist)
                chi_square_values.append(chi_square)
                
                # Calculate p-value (degrees of freedom = 255)
                p_value = 1 - stats.chi2.cdf(chi_square, df=255)
                p_values.append(p_value)
            
            avg_chi_square = np.mean(chi_square_values)
            avg_p_value = np.mean(p_values)
            
            return avg_chi_square, avg_p_value
        
        except Exception as e:
            self.log_message(f"Chi-square test error: {str(e)}")
            return 0, 1.0

    def analyze_quality_metrics(self, cover_video_path, stego_video_path, secret_data_size):
        """Analyze quality metrics after encoding"""
        try:
            self.log_message("Starting quality analysis...")
            
            self.cover_frames = self.video_processor.load_video_frames(cover_video_path, max_frames=10)
            self.stego_frames = self.video_processor.load_video_frames(stego_video_path, max_frames=10)
            
            if self.cover_frames is None or self.stego_frames is None:
                self.log_message("Warning: Could not load frames for quality analysis")
                return

            self.cover_histogram = self.calculate_histogram(self.cover_frames)
            self.stego_histogram = self.calculate_histogram(self.stego_frames)
            
            mse = self.calculate_mse(self.cover_frames, self.stego_frames)
            psnr = self.calculate_psnr(mse)
            ssim = self.calculate_ssim(self.cover_frames, self.stego_frames)
            correlation = self.calculate_histogram_correlation(self.cover_histogram, self.stego_histogram)
            
            if hasattr(self, 'max_secret_size') and self.max_secret_size > 0:
                payload_capacity = self.calculate_payload_capacity(secret_data_size, self.max_secret_size)
            else:
                payload_capacity = 0
            
            # Perform chi-square test
            chi_square, p_value = self.chi_square_test(self.cover_frames, self.stego_frames)
            
            self.quality_metrics = {
                'mse': mse,
                'psnr': psnr,
                'ssim': ssim,
                'correlation': correlation,
                'payload_capacity': payload_capacity,
                'secret_data_size': secret_data_size,
                'chi_square': chi_square,
                'p_value': p_value
            }
            
            self.display_quality_metrics()
            self.quality_frame.pack(fill=tk.X, padx=10, pady=5)
            
            self.log_message("Quality analysis completed")

        except Exception as e:
            self.log_message(f"Error in quality analysis: {str(e)}")

    def display_quality_metrics(self):
        """Display quality metrics in the GUI with improved formatting"""
        if not self.quality_metrics:
            return
        
        metrics_text = f"""╔══════════════════════════════════════════════════════════════╗
║              QUALITY ANALYSIS RESULTS                        ║
╚══════════════════════════════════════════════════════════════╝

📊 IMAGE QUALITY METRICS:
   • MSE (Mean Square Error):      {self.quality_metrics['mse']:.4f}
   • PSNR (Peak Signal-to-Noise):  {self.quality_metrics['psnr']:.2f} dB
   • SSIM (Structural Similarity): {self.quality_metrics['ssim']:.4f}
   • Histogram Correlation:        {self.quality_metrics['correlation']:.4f}

📦 PAYLOAD INFORMATION:
   • Secret Data Size:             {self.quality_metrics['secret_data_size']} bytes ({self.quality_metrics['secret_data_size']/1024:.2f} KB)
   • Payload Capacity Used:        {self.quality_metrics['payload_capacity']:.2f}%
   • Embedding Rate:               {self.quality_metrics['payload_capacity']/100:.4f}

🔍 STEGANALYSIS DETECTION:
   • Chi-Square Statistic:         {self.quality_metrics['chi_square']:.2f}
   • P-Value:                      {self.quality_metrics['p_value']:.4f}
   • Detection Risk:               {'LOW' if self.quality_metrics['p_value'] > 0.05 else 'HIGH'}

📝 INTERPRETATION:
   • Lower MSE = Better quality (closer to original)
   • Higher PSNR = Better quality (>30 dB is good, >40 dB is excellent)
   • SSIM close to 1.0 = More similar to original
   • Histogram correlation close to 1.0 = Less detectable
   • P-Value > 0.05 = Statistically harder to detect
"""
        
        self.metrics_text.delete(1.0, tk.END)
        self.metrics_text.insert(1.0, metrics_text)

    def show_grayscale_histogram(self):
        """Show grayscale histogram comparison (Cover vs Stego) side by side"""
        if self.cover_histogram is None or self.stego_histogram is None:
            messagebox.showwarning("Warning", "No histogram data available. Please encode data first.")
            return
        
        # Create new window for histogram
        if self.histogram_window is not None and self.histogram_window.winfo_exists():
            self.histogram_window.destroy()
        
        self.histogram_window = tk.Toplevel(self.window)
        self.histogram_window.title("Grayscale Histogram Analysis")
        self.histogram_window.geometry("1200x600")
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
        
        # Cover histogram
        ax1.hist(self.cover_histogram, bins=256, alpha=0.7, color='blue', edgecolor='black')
        ax1.set_title('Cover Video - Grayscale Histogram', fontsize=14, fontweight='bold')
        ax1.set_xlabel('Pixel Intensity', fontsize=12)
        ax1.set_ylabel('Frequency', fontsize=12)
        ax1.grid(True, alpha=0.3)
        
        # Stego histogram
        ax2.hist(self.stego_histogram, bins=256, alpha=0.7, color='red', edgecolor='black')
        ax2.set_title('Stego Video - Grayscale Histogram', fontsize=14, fontweight='bold')
        ax2.set_xlabel('Pixel Intensity', fontsize=12)
        ax2.set_ylabel('Frequency', fontsize=12)
        ax2.grid(True, alpha=0.3)
        
        # Add correlation text
        correlation = self.quality_metrics.get('correlation', 0)
        fig.text(0.5, 0.02, f'Histogram Correlation: {correlation:.4f}', 
                ha='center', fontsize=11, fontweight='bold')
        
        plt.tight_layout(rect=[0, 0.03, 1, 1])
        
        canvas = FigureCanvasTkAgg(fig, master=self.histogram_window)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

    def show_rgb_histograms(self):
        """Show RGB histogram comparison (Cover vs Stego) side by side"""
        if self.cover_frames is None or self.stego_frames is None:
            messagebox.showwarning("Warning", "No frame data available. Please encode data first.")
            return
        
        if self.histogram_window is not None and self.histogram_window.winfo_exists():
            self.histogram_window.destroy()
        
        self.histogram_window = tk.Toplevel(self.window)
        self.histogram_window.title("RGB Channel Histogram Analysis")
        self.histogram_window.geometry("1400x800")
        
        # Create scrollable canvas
        canvas_frame = ttk.Frame(self.histogram_window)
        canvas_frame.pack(fill=tk.BOTH, expand=True)
        
        canvas = tk.Canvas(canvas_frame)
        scrollbar_v = ttk.Scrollbar(canvas_frame, orient="vertical", command=canvas.yview)
        scrollbar_h = ttk.Scrollbar(canvas_frame, orient="horizontal", command=canvas.xview)
        
        fig, axes = plt.subplots(2, 3, figsize=(18, 10))
        
        # Process cover frames
        cover_r, cover_g, cover_b = [], [], []
        for frame in self.cover_frames:
            cover_b.extend(frame[:, :, 0].flatten())
            cover_g.extend(frame[:, :, 1].flatten())
            cover_r.extend(frame[:, :, 2].flatten())
        
        # Process stego frames
        stego_r, stego_g, stego_b = [], [], []
        for frame in self.stego_frames:
            stego_b.extend(frame[:, :, 0].flatten())
            stego_g.extend(frame[:, :, 1].flatten())
            stego_r.extend(frame[:, :, 2].flatten())
        
        colors = ['blue', 'green', 'red']
        channels = ['Blue', 'Green', 'Red']
        
        # Cover histograms
        for i, (data, color, channel) in enumerate(zip([cover_b, cover_g, cover_r], colors, channels)):
            axes[0, i].hist(data, bins=256, alpha=0.7, color=color, edgecolor='black')
            axes[0, i].set_title(f'Cover - {channel} Channel', fontsize=14, fontweight='bold')
            axes[0, i].set_xlabel('Pixel Intensity', fontsize=12)
            axes[0, i].set_ylabel('Frequency', fontsize=12)
            axes[0, i].grid(True, alpha=0.3)
        
        # Stego histograms
        for i, (data, color, channel) in enumerate(zip([stego_b, stego_g, stego_r], colors, channels)):
            axes[1, i].hist(data, bins=256, alpha=0.7, color=color, edgecolor='black')
            axes[1, i].set_title(f'Stego - {channel} Channel', fontsize=14, fontweight='bold')
            axes[1, i].set_xlabel('Pixel Intensity', fontsize=12)
            axes[1, i].set_ylabel('Frequency', fontsize=12)
            axes[1, i].grid(True, alpha=0.3)
        
        plt.tight_layout(pad=3.0)
        
        fig_canvas = FigureCanvasTkAgg(fig, master=self.histogram_window)
        fig_canvas.draw()
        fig_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

    def show_difference_histogram(self):
        """Show histogram of pixel differences between Cover and Stego"""
        if self.cover_frames is None or self.stego_frames is None:
            messagebox.showwarning("Warning", "No frame data available. Please encode data first.")
            return
        
        if self.histogram_window is not None and self.histogram_window.winfo_exists():
            self.histogram_window.destroy()
        
        self.histogram_window = tk.Toplevel(self.window)
        self.histogram_window.title("Difference Histogram Analysis")
        self.histogram_window.geometry("1200x600")
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
        
        # Calculate differences
        differences = []
        for cover_frame, stego_frame in zip(self.cover_frames, self.stego_frames):
            cover_gray = cv2.cvtColor(cover_frame, cv2.COLOR_BGR2GRAY)
            stego_gray = cv2.cvtColor(stego_frame, cv2.COLOR_BGR2GRAY)
            diff = stego_gray.astype(np.int16) - cover_gray.astype(np.int16)
            differences.extend(diff.flatten())
        
        differences = np.array(differences)
        
        # Absolute differences
        abs_diff = np.abs(differences)
        ax1.hist(abs_diff, bins=50, alpha=0.7, color='orange', edgecolor='black')
        ax1.set_title('Absolute Pixel Differences |Stego - Cover|', fontsize=14, fontweight='bold')
        ax1.set_xlabel('Difference Magnitude', fontsize=12)
        ax1.set_ylabel('Frequency', fontsize=12)
        ax1.grid(True, alpha=0.3)
        ax1.axvline(x=np.mean(abs_diff), color='red', linestyle='--', linewidth=2, label=f'Mean: {np.mean(abs_diff):.2f}')
        ax1.legend()
        
        # Signed differences
        ax2.hist(differences, bins=100, alpha=0.7, color='purple', edgecolor='black')
        ax2.set_title('Signed Pixel Differences (Stego - Cover)', fontsize=14, fontweight='bold')
        ax2.set_xlabel('Difference Value', fontsize=12)
        ax2.set_ylabel('Frequency', fontsize=12)
        ax2.grid(True, alpha=0.3)
        ax2.axvline(x=0, color='red', linestyle='--', linewidth=2, label='Zero Difference')
        ax2.legend()
        
        # Statistics
        stats_text = f'Max Diff: {np.max(abs_diff):.2f} | Mean: {np.mean(abs_diff):.2f} | Std: {np.std(abs_diff):.2f}'
        fig.text(0.5, 0.02, stats_text, ha='center', fontsize=11, fontweight='bold')
        
        plt.tight_layout(rect=[0, 0.03, 1, 1])
        
        canvas = FigureCanvasTkAgg(fig, master=self.histogram_window)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

    def show_bitplane_analysis(self):
        """Show LSB bit-plane analysis for steganalysis"""
        if self.cover_frames is None or self.stego_frames is None:
            messagebox.showwarning("Warning", "No frame data available. Please encode data first.")
            return
        
        if self.histogram_window is not None and self.histogram_window.winfo_exists():
            self.histogram_window.destroy()
        
        self.histogram_window = tk.Toplevel(self.window)
        self.histogram_window.title("Bit-Plane Analysis (LSB Detection)")
        self.histogram_window.geometry("1400x900")
        
        fig, axes = plt.subplots(3, 3, figsize=(15, 12))
        fig.suptitle('Bit-Plane Analysis: LSB Steganography Detection', fontsize=16, fontweight='bold')
        
        # Use first frame for visualization
        cover_gray = cv2.cvtColor(self.cover_frames[0], cv2.COLOR_BGR2GRAY)
        stego_gray = cv2.cvtColor(self.stego_frames[0], cv2.COLOR_BGR2GRAY)
        
        # Extract and visualize bit planes
        for bit in range(8):
            row = bit // 3
            col = bit % 3
            
            # Cover bit plane
            cover_bitplane = (cover_gray >> bit) & 1
            
            # Stego bit plane
            stego_bitplane = (stego_gray >> bit) & 1
            
            # Show difference
            diff_bitplane = np.abs(cover_bitplane.astype(np.int16) - stego_bitplane.astype(np.int16))
            
            # Visualize
            im = axes[row, col].imshow(diff_bitplane * 255, cmap='hot', vmin=0, vmax=255)
            axes[row, col].set_title(f'Bit Plane {bit} Difference', fontsize=11, fontweight='bold')
            axes[row, col].axis('off')
            
            # Add colorbar
            plt.colorbar(im, ax=axes[row, col], fraction=0.046, pad=0.04)
        
        # LSB histogram comparison
        ax_lsb = axes[2, 2]
        cover_lsb = cover_gray & 1
        stego_lsb = stego_gray & 1
        
        cover_lsb_hist = np.bincount(cover_lsb.flatten(), minlength=2)
        stego_lsb_hist = np.bincount(stego_lsb.flatten(), minlength=2)
        
        x = np.arange(2)
        width = 0.35
        ax_lsb.bar(x - width/2, cover_lsb_hist, width, label='Cover LSB', alpha=0.7, color='blue')
        ax_lsb.bar(x + width/2, stego_lsb_hist, width, label='Stego LSB', alpha=0.7, color='red')
        ax_lsb.set_xlabel('LSB Value', fontsize=11)
        ax_lsb.set_ylabel('Frequency', fontsize=11)
        ax_lsb.set_title('LSB Distribution', fontsize=11, fontweight='bold')
        ax_lsb.set_xticks(x)
        ax_lsb.legend()
        ax_lsb.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        canvas = FigureCanvasTkAgg(fig, master=self.histogram_window)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

    def show_statistical_detection(self):
        """Show statistical steganalysis detection metrics"""
        if self.cover_frames is None or self.stego_frames is None:
            messagebox.showwarning("Warning", "No frame data available. Please encode data first.")
            return
        
        if self.histogram_window is not None and self.histogram_window.winfo_exists():
            self.histogram_window.destroy()
        
        self.histogram_window = tk.Toplevel(self.window)
        self.histogram_window.title("Statistical Steganalysis Detection")
        self.histogram_window.geometry("1200x800")
        
        fig = plt.figure(figsize=(12, 10))
        gs = fig.add_gridspec(3, 2, hspace=0.3, wspace=0.3)
        
        # 1. Chi-Square Test Results
        ax1 = fig.add_subplot(gs[0, :])
        chi_square = self.quality_metrics.get('chi_square', 0)
        p_value = self.quality_metrics.get('p_value', 1.0)
        
        chi_text = f"""Chi-Square Steganalysis Test
        
Chi-Square Statistic: {chi_square:.2f}
P-Value: {p_value:.4f}
Detection Risk: {'LOW (p > 0.05)' if p_value > 0.05 else 'HIGH (p ≤ 0.05)'}

Interpretation:
• p > 0.05: Statistically similar to cover video (harder to detect)
• p ≤ 0.05: Statistically different from cover video (easier to detect)
        """
        
        ax1.text(0.5, 0.5, chi_text, ha='center', va='center', fontsize=12, 
                family='monospace', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        ax1.axis('off')
        
        # 2. LSB Pair Analysis
        ax2 = fig.add_subplot(gs[1, 0])
        cover_gray = cv2.cvtColor(self.cover_frames[0], cv2.COLOR_BGR2GRAY)
        stego_gray = cv2.cvtColor(self.stego_frames[0], cv2.COLOR_BGR2GRAY)
        
        # Count LSB pairs
        cover_lsb = cover_gray & 1
        stego_lsb = stego_gray & 1
        
        cover_pairs = np.sum(cover_lsb)
        stego_pairs = np.sum(stego_lsb)
        
        labels = ['Cover 0s', 'Cover 1s', 'Stego 0s', 'Stego 1s']
        values = [cover_gray.size - cover_pairs, cover_pairs, 
                 stego_gray.size - stego_pairs, stego_pairs]
        colors = ['lightblue', 'blue', 'lightcoral', 'red']
        
        ax2.bar(labels, values, color=colors, alpha=0.7)
        ax2.set_title('LSB Bit Distribution', fontsize=12, fontweight='bold')
        ax2.set_ylabel('Count', fontsize=11)
        ax2.grid(True, alpha=0.3, axis='y')
        ax2.tick_params(axis='x', rotation=45)
        
        # 3. Entropy Analysis
        ax3 = fig.add_subplot(gs[1, 1])
        
        from scipy.stats import entropy
        
        cover_hist, _ = np.histogram(cover_gray.flatten(), bins=256, range=(0, 256))
        stego_hist, _ = np.histogram(stego_gray.flatten(), bins=256, range=(0, 256))
        
        cover_entropy = entropy(cover_hist + 1)  # Add 1 to avoid log(0)
        stego_entropy = entropy(stego_hist + 1)
        
        entropy_labels = ['Cover Video', 'Stego Video']
        entropy_values = [cover_entropy, stego_entropy]
        colors_entropy = ['green', 'orange']
        
        ax3.bar(entropy_labels, entropy_values, color=colors_entropy, alpha=0.7)
        ax3.set_title('Shannon Entropy Comparison', fontsize=12, fontweight='bold')
        ax3.set_ylabel('Entropy (bits)', fontsize=11)
        ax3.grid(True, alpha=0.3, axis='y')
        ax3.axhline(y=cover_entropy, color='green', linestyle='--', alpha=0.5)
        
        # 4. Quality Metrics Summary
        ax4 = fig.add_subplot(gs[2, :])
        
        metrics_summary = f"""Overall Quality & Detection Metrics Summary

MSE: {self.quality_metrics.get('mse', 0):.4f}  |  PSNR: {self.quality_metrics.get('psnr', 0):.2f} dB  |  SSIM: {self.quality_metrics.get('ssim', 0):.4f}
Histogram Correlation: {self.quality_metrics.get('correlation', 0):.4f}
Payload Capacity Used: {self.quality_metrics.get('payload_capacity', 0):.2f}%
Cover Entropy: {cover_entropy:.4f}  |  Stego Entropy: {stego_entropy:.4f}

DETECTABILITY ASSESSMENT:
{'✓ LOW RISK - Good steganographic quality' if p_value > 0.05 and self.quality_metrics.get('psnr', 0) > 35 else '⚠ MEDIUM-HIGH RISK - May be detectable by steganalysis'}
        """
        
        ax4.text(0.5, 0.5, metrics_summary, ha='center', va='center', fontsize=11,
                family='monospace', bbox=dict(boxstyle='round', facecolor='lightgreen' if p_value > 0.05 else 'lightyellow', alpha=0.7))
        ax4.axis('off')
        
        plt.suptitle('Statistical Steganalysis Report', fontsize=14, fontweight='bold', y=0.98)
        
        canvas = FigureCanvasTkAgg(fig, master=self.histogram_window)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)


class DecodeWindow:
    """Decode window with all decoding functionality"""
    
    def __init__(self, parent=None):
        self.parent = parent
        self.window = tk.Toplevel(parent) if parent else tk.Tk()
        self.window.title("Decode Hidden Data")
        self.window.geometry("700x550")
        self.window.resizable(True, True)
        self.window.minsize(600, 500)
        
        self.center_window()
        
        self.video_processor = VideoProcessor()
        self.file_handler = FileHandler()
        self.stego_engine = SteganographyEngine()
        
        self.extract_video_path = tk.StringVar()
        self.extract_output_path = tk.StringVar()
        self.extract_password = tk.StringVar()
        self.use_extract_password = tk.BooleanVar()
        self.algorithm = tk.StringVar(value="LSB")
        
        self.progress_var = tk.DoubleVar()
        self.status_var = tk.StringVar(value="Ready")
        
        self.setup_gui()
        self.log_message("Decode window initialized")
    
    def center_window(self):
        """Center the window on screen"""
        self.window.update_idletasks()
        width = self.window.winfo_width()
        height = self.window.winfo_height()
        x = (self.window.winfo_screenwidth() // 2) - (width // 2)
        y = (self.window.winfo_screenheight() // 2) - (height // 2)
        self.window.geometry(f'{width}x{height}+{x}+{y}')
    
    def setup_gui(self):
        """Setup the decode GUI"""
        main_frame = ttk.Frame(self.window)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        title_label = ttk.Label(main_frame, text="Decode Hidden Data", 
                               font=("Arial", 16, "bold"))
        title_label.pack(pady=(0, 15))
        
        # Input video section
        input_frame = ttk.LabelFrame(main_frame, text="Steganographic Video", padding=10)
        input_frame.pack(fill=tk.X, pady=5)
        
        input_entry_frame = ttk.Frame(input_frame)
        input_entry_frame.pack(fill=tk.X)
        ttk.Entry(input_entry_frame, textvariable=self.extract_video_path).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        ttk.Button(input_entry_frame, text="Browse", command=self.select_extract_video).pack(side=tk.RIGHT)
        
        # Algorithm section
        algo_frame = ttk.LabelFrame(main_frame, text="Steganography Algorithm", padding=10)
        algo_frame.pack(fill=tk.X, pady=5)
        
        ttk.Radiobutton(algo_frame, text="LSB (Least Significant Bit)", 
                       variable=self.algorithm, value="LSB").pack(anchor=tk.W)
        ttk.Radiobutton(algo_frame, text="DCT (Discrete Cosine Transform)", 
                       variable=self.algorithm, value="DCT").pack(anchor=tk.W)
        
        # Password section
        password_frame = ttk.LabelFrame(main_frame, text="Decryption (If Used)", padding=10)
        password_frame.pack(fill=tk.X, pady=5)
        
        ttk.Checkbutton(password_frame, text="File is password protected", 
                       variable=self.use_extract_password).pack(anchor=tk.W)
        
        pwd_entry_frame = ttk.Frame(password_frame)
        pwd_entry_frame.pack(fill=tk.X, pady=(5, 0))
        ttk.Label(pwd_entry_frame, text="Password:").pack(side=tk.LEFT)
        ttk.Entry(pwd_entry_frame, textvariable=self.extract_password, show="*").pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5, 0))
        
        # Output directory section
        output_frame = ttk.LabelFrame(main_frame, text="Output Directory", padding=10)
        output_frame.pack(fill=tk.X, pady=5)
        
        output_entry_frame = ttk.Frame(output_frame)
        output_entry_frame.pack(fill=tk.X)
        ttk.Entry(output_entry_frame, textvariable=self.extract_output_path).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        ttk.Button(output_entry_frame, text="Browse", command=self.select_extract_output).pack(side=tk.RIGHT)
        
        # Decode button
        ttk.Button(main_frame, text="Decode Hidden Data", 
                  command=self.decode_data_thread, style="Accent.TButton").pack(pady=15)
        
        # Progress section
        progress_frame = ttk.LabelFrame(main_frame, text="Progress", padding=10)
        progress_frame.pack(fill=tk.X, pady=5)
        
        self.progress_bar = ttk.Progressbar(progress_frame, variable=self.progress_var, 
                                          maximum=100, mode='determinate')
        self.progress_bar.pack(fill=tk.X, pady=(0, 5))
        
        self.status_label = ttk.Label(progress_frame, textvariable=self.status_var)
        self.status_label.pack()
        
        # Log section
        log_frame = ttk.LabelFrame(main_frame, text="Log", padding=10)
        log_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.log_text = scrolledtext.ScrolledText(log_frame, height=8)
        self.log_text.pack(fill=tk.BOTH, expand=True)
        
        ttk.Button(log_frame, text="Clear Log", command=self.clear_log).pack(pady=(5, 0))
    
    def log_message(self, message):
        """Add message to log with timestamp"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        log_entry = f"[{timestamp}] {message}\n"
        self.log_text.insert(tk.END, log_entry)
        self.log_text.see(tk.END)
        self.window.update_idletasks()
    
    def clear_log(self):
        """Clear the log window"""
        self.log_text.delete(1.0, tk.END)
    
    def select_extract_video(self):
        """Select video for data extraction"""
        filetypes = [
            ("Video files", "*.mp4 *.avi *.mov *.mkv"),
            ("All files", "*.*")
        ]
        
        filename = filedialog.askopenfilename(
            title="Select Steganographic Video",
            filetypes=filetypes
        )
        
        if filename:
            self.extract_video_path.set(filename)
    
    def select_extract_output(self):
        """Select output directory for extracted files"""
        directory = filedialog.askdirectory(title="Select Output Directory")
        
        if directory:
            self.extract_output_path.set(directory)
    
    def decode_data_thread(self):
        """Start decode data operation in separate thread"""
        thread = threading.Thread(target=self.decode_data)
        thread.daemon = True
        thread.start()
    
    def decode_data(self):
        """Decode data from video"""
        try:
            if not self.extract_video_path.get():
                messagebox.showerror("Error", "Please select a steganographic video")
                return
            
            if not self.extract_output_path.get():
                messagebox.showerror("Error", "Please specify output directory")
                return
            
            self.status_var.set("Extracting data...")
            self.progress_var.set(10)
            self.log_message("Starting data extraction process...")
            
            result = self.stego_engine.extract_data_with_backup(
                self.extract_video_path.get(),
                self.algorithm.get(),
                self.update_progress
            )
            
            if result is None:
                self.log_message("No hidden data found in video")
                messagebox.showwarning("Warning", "No hidden data found in video")
                self.status_var.set("No data found")
                return
            
            secret_data, metadata = result
            self.progress_var.set(70)
            
            if metadata.get('encrypted', False):
                if not self.use_extract_password.get() or not self.extract_password.get():
                    messagebox.showerror("Error", "This file is password protected. Please enter the password.")
                    self.status_var.set("Password required")
                    return
                
                self.log_message("Decrypting extracted data...")
                try:
                    secret_data = self.decrypt_data(secret_data, self.extract_password.get())
                    self.log_message("Data decrypted successfully")
                except Exception as e:
                    self.log_message(f"Decryption failed: {str(e)}")
                    messagebox.showerror("Error", "Invalid password or corrupted data")
                    self.status_var.set("Decryption failed")
                    return
            else:
                if self.use_extract_password.get() and self.extract_password.get():
                    self.log_message("Warning: Password provided but data was not encrypted")
                    result = messagebox.askyesno("Password Warning", 
                        "This file was not encrypted during hiding, but you provided a password.\n\n"
                        "Do you want to proceed without using the password?")
                    if not result:
                        return
            
            self.progress_var.set(90)
            
            output_filename = os.path.join(
                self.extract_output_path.get(),
                metadata.get('filename', f"extracted_file{metadata.get('extension', '.bin')}")
            )
            
            self.file_handler.write_file(output_filename, secret_data)
            
            self.progress_var.set(100)
            self.status_var.set("Data extracted successfully!")
            self.log_message(f"Success! Extracted file saved to: {output_filename}")
            messagebox.showinfo("Success", f"Data extracted successfully!\nSaved to: {output_filename}")
            
        except Exception as e:
            self.log_message(f"Error during extraction process: {str(e)}")
            messagebox.showerror("Error", f"Failed to extract data:\n{str(e)}")
            self.status_var.set("Error occurred")
    
    def update_progress(self, percentage):
        """Update progress bar"""
        self.progress_var.set(percentage)
        self.window.update_idletasks()
    
    def decrypt_data(self, encrypted_data, password):
        """Decrypt data using password"""
        salt = encrypted_data[:16]
        encrypted_data = encrypted_data[16:]
        
        password_bytes = password.encode()
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        key = base64.urlsafe_b64encode(kdf.derive(password_bytes))
        
        fernet = Fernet(key)
        decrypted_data = fernet.decrypt(encrypted_data)
        
        return decrypted_data


def main():
    """Main function to run the application"""
    root = tk.Tk()
    
    # Set application icon (if available)
    try:
        root.iconbitmap('icon.ico')
    except:
        pass
    
    # Configure style
    style = ttk.Style()
    style.theme_use('clam')
    
    # Create and run home window
    home_window = HomeWindow(root)
    
    try:
        root.mainloop()
    except KeyboardInterrupt:
        print("Application terminated by user")


if __name__ == "__main__":
    main()