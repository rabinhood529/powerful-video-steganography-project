# Video Steganography Project

A Python-based video steganography tool that allows you to hide and extract secret messages within video files.

## Features

- Hide text messages in video files
- Extract hidden messages from steganographic videos
- Backup and restore functionality

## Installation

1. Clone this repository
2. Install required dependencies:
```
   pip install -r requirements.txt
```

## Usage

Run the main program:
```
python launcher.py
```

## Requirements

- Python 3.10+
- OpenCV
- NumPy